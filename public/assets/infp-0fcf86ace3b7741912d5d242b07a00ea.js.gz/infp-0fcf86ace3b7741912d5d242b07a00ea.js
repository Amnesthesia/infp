(function() {
  $(document).ready(function() {
    return $("header > .wrapper > .content > h1").typed({
      strings: ["Hi.<br />Let's write letters. Real live actual paper letters. <br>It's really easy. Click the Facebook or Reddit icon to sign in, and enter your email - that's it! <br /><br />We'll pair you up randomly and send you both an email or a message on reddit with eachothers details. <br /><br />All you need then is a pen, check your pockets!"],
      typeSpeed: 10
    });
  });

}).call(this);
